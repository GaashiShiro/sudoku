Here's a nice light-hearted loop I put together in Soundtracker. It's not
much, but I could listen to it for hours on end. You're free to use this in
your projects under the terms of the Creative Commons - Attribution - Share
Alike license (CC-BY-SA) or the GPL, whichever you find more convenient.
Where appropriate, please attribute your usage to:

Barry "Ishara" Peddycord <http://isharacomix.com>

The terms of the GPL are available in the COPYING_GPL.txt file, and the terms
of the CC-BY-SA license are available in the COPYING_CC_BY_SA.txt file.

